<?php $__env->startSection('content'); ?>
    <main>
        <div class="container-fluid px-4">
            <h1 class="mt-4">Orders</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item"><a href="index.html">Dashboard</a></li>
                <li class="breadcrumb-item active">Orders</li>
            </ol>
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-table me-1"></i>
                    All Orders
                </div>
                <div class="card-body">
                    <?php echo $__env->make('flash_data', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <table id="datatablesSimple">
                        <thead>
                        <tr>
                            <th>Order Id</th>
                            <th>User Name</th>
                            <th>Sub Total</th>
                            <th>Tax Rate</th>
                            <th>Tax Amount</th>
                            <th>Shipping</th>
                            <th>Total Amount</th>
                            <th>Comment</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tfoot>
                        <tr>
                            <th>Order Id</th>
                            <th>User Name</th>
                            <th>Sub Total</th>
                            <th>Tax Rate</th>
                            <th>Tax Amount</th>
                            <th>Shipping</th>
                            <th>Total Amount</th>
                            <th>Comment</th>
                            <th>Action</th>
                        </tr>
                        </tfoot>
                        <tbody>
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>LV- <?php echo e($order->id); ?></td>
                                <td><?php echo e($order->customerData->full_name); ?></td>
                                <td><?php echo e($order->sub_total); ?></td>
                                <td><?php echo e($order->tax_rate); ?></td>
                                <td><?php echo e($order->tax_amount); ?></td>
                                <td><?php echo e($order->shipping); ?></td>
                                <td><?php echo e($order->amount); ?></td>
                                <td><?php echo e($order->comment); ?></td>
                                <td style="max-width: 30px">
                                    <form method="post" action="<?php echo e(route('admin_change_order_status', ['id' => $order->id])); ?>">
                                        <?php echo csrf_field(); ?>
                                        <select class="form-select" id="status"
                                                aria-label="Default select example"
                                                required="" name="status">
                                            <option selected disabled>Select</option>
                                            <?php $__currentLoopData = \Illuminate\Support\Facades\Config::get('order_status'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($status); ?>" <?php if($status == $order->status): ?> <?php echo e('selected'); ?> <?php endif; ?>><?php echo e($status); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <input type="submit" class="btn btn-sm btn-primary" value="Update Status">
                                    </form>
                                    <a href="<?php echo e(route('get_line_items', ['id' => $order->id])); ?>"
                                       class="btn btn-sm btn-warning">View</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\learnvern-watch-store\resources\views/admin/orders_list.blade.php ENDPATH**/ ?>
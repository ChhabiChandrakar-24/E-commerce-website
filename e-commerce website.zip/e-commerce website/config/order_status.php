<?php

return [
    'Order Placed',
    'Out For Delivery',
    'Delivered',
    'Returned',
];

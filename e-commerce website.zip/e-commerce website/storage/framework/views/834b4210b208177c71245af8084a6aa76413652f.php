<footer class="py-5 bg-dark">
    <div class="container"><p class="m-0 text-center text-white">Copyright &copy;chhabi E-commerce web </p></div>
</footer>
<?php /**PATH C:\xampp\htdocs\myapp\e-commerce website\resources\views/footer_user.blade.php ENDPATH**/ ?>
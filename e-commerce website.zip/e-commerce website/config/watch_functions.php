<?php

return [
    'Analog',
    'Automatic',
    'Mechanical',
    'Smart',
    'Digital',
];

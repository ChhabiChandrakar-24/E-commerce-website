<?php

return [
    [
        'name' => 'apple',
        'image' => 'apple.png',
    ],
    [
        'name' => 'breitling',
        'image' => 'breitling.jpg',
    ],
    [
        'name' => 'cartier',
        'image' => 'cartier.png',
    ],
    [
        'name' => 'casio',
        'image' => 'casio.jpg',
    ],
    [
        'name' => 'diesel',
        'image' => 'diesel.png',
    ],
    [
        'name' => 'fastrack',
        'image' => 'fastrack.png',
    ],
    [
        'name' => 'fossil',
        'image' => 'fossil.jpg',
    ],
    [
        'name' => 'hamilton',
        'image' => 'hamilton.png',
    ],
    [
        'name' => 'hublot',
        'image' => 'hublot.png',
    ],
    [
        'name' => 'omega',
        'image' => 'omega.png',
    ],
    [
        'name' => 'rado',
        'image' => 'rado.png',
    ],
    [
        'name' => 'roadster',
        'image' => 'roadster.jpg',
    ],
    [
        'name' => 'rolex',
        'image' => 'rolex.png',
    ],
    [
        'name' => 'swatch',
        'image' => 'swatch.png',
    ],
    [
        'name' => 'tag_heuer',
        'image' => 'tag_heuer.png',
    ],
    [
        'name' => 'tissot',
        'image' => 'tissot.png',
    ],
    [
        'name' => 'titan',
        'image' => 'titan.jpg',
    ],
];

Hi, we have received your request for password reset.

Please click <a href="<?php echo e(env('APP_URL') . 'reset-password/' . $token . '?email=' . urlencode($email)); ?>"> here </a> to reset your password.

Thanks,
chhabi Web Store Team.
<?php /**PATH C:\xampp\htdocs\myapp\e-commerce website\resources\views/forgot_password_email.blade.php ENDPATH**/ ?>
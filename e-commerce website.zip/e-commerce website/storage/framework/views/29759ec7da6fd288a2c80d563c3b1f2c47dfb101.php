<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <!-- Start col -->
        <div class="album py-5" style="height:60vh;">
            <div class="row h-100 justify-content-center align-items-center">
                <div class="card border-success" style="margin-top: 4%;max-width: 35rem;padding: 2%;">
                    <h2> Login </h2>
                    <?php echo $__env->make('flash_data', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li> <?php echo e($error); ?> </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <hr>
                    <div class="card-body">
                        <form action="<?php echo e(route('authenticate')); ?>" method="POST" name="loginForm" enctype="multipart/from-data">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="emailInput">Email address:</label>
                                <input type="email" class="form-control" name="email" id="email"
                                       required="required" placeholder="Enter email">
                            </div>
                            <br>
                            <div class="form-group">
                                <label for="passInput">Password:</label>
                                <input type="password" class="form-control" name="password" id="password"
                                       required="required" placeholder="Password">
                            </div>
                            <br>
                            <center>
                                <input type="submit" name="loginbtn" class="btn btn-outline-success" value="Login">
                                <input type="reset" class="btn btn-outline-danger">
                            </center>
                        </form>
                        <div style="margin-top: -8%;">
                            <a href="<?php echo e(route('register')); ?>" class="float-end">New User?</a><br>
                            <a href="<?php echo e(route('forgot_password')); ?>" class="float-end">Forgot Password?</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('store_locator', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\learnvern-watch-store\resources\views/login.blade.php ENDPATH**/ ?>
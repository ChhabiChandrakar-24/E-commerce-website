<?php $__env->startSection('content'); ?>
    <!-- Product section-->
    <section class="py-5">
        <div class="container px-4 px-lg-5 my-5">
            <div class="row gx-4 gx-lg-5 align-items-center">
                <div class="col-md-6"><img class="card-img-top mb-5 mb-md-0" src="<?php echo e($product->image); ?>"
                                           alt="Product Image"/></div>
                <div class="col-md-6">
                    <div class="small mb-1"><?php echo e($product->product_code); ?></div>
                    <h1 class="display-5 fw-bolder"><?php echo e($product->product_name); ?></h1>
                    <div class="fs-5 mb-5">
                        <?php if(empty($product->sale_price)): ?>
                            <span class="text-decoration-line-through">₹<?php echo e($product->price); ?></span>
                            <span><?php echo e('₹' . $product->sale_price); ?></span>
                        <?php else: ?>
                            <span><?php echo e('₹' . $product->price); ?></span>
                        <?php endif; ?>
                    </div>
                    <p class="lead"><?php echo e($product->description); ?></p>
                    <div class="d-flex">
                        <form method="post" action="<?php echo e(route('add_to_cart')); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                            <input class="form-control text-center me-3" id="inputQuantity" name="quantity" type="num" min="1" value="1"
                                   style="max-width: 3rem"/>
                            <input class="btn btn-outline-dark flex-shrink-0" type="submit" value="Add to cart" />
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Related items section-->
    <section class="py-5">
        <div class="container px-4 px-lg-5 mt-5">
            <h2 class="fw-bolder mb-4">Related products</h2>
            <div class="row gx-4 gx-lg-5 row-cols-2 row-cols-md-3 row-cols-xl-4 justify-content-center">
                <?php $__currentLoopData = $relatedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relatedProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col mb-5">
                        <div class="card h-100">
                            <!-- Sale badge-->
                            <?php if(empty($relatedProduct->sale_price) && $relatedProduct->stock != 0): ?>
                                <div class="badge bg-dark text-white position-absolute"
                                     style="top: 0.5rem; right: 0.5rem"> Sale
                                </div>
                            <?php elseif($relatedProduct->stock == 0): ?>
                                <div class="badge bg-danger text-white position-absolute"
                                     style="top: 0.5rem; right: 0.5rem"> Out Of Stock
                                </div>
                        <?php endif; ?>
                        <!-- Product image-->
                            <img class="card-img-top" src="<?php echo e($relatedProduct->image); ?>" alt="Product Image"/>
                        
                        <!-- Product details-->
                            <div class="card-body p-4">
                                <div class="text-center">
                                    <!-- Product name-->
                                    <h5 class="fw-bolder"><?php echo e($relatedProduct->product_name); ?></h5>
                                    <!-- Product price-->
                                    <?php if(empty($relatedProduct->sale_price)): ?>
                                        <span
                                            class="text-muted text-decoration-line-through"><?php echo e('₹' . $relatedProduct->price); ?></span>
                                        <?php echo e('₹' . $relatedProduct->sale_price); ?>

                                    <?php else: ?>
                                        <?php echo e('₹' . $relatedProduct->price); ?>

                                    <?php endif; ?><br>
                                    <h6><?php echo e('For: ' . $relatedProduct->gender); ?></h6>
                                    <h6><?php echo e('Function: ' . $relatedProduct->function); ?></h6>
                                </div>
                            </div>
                            <!-- Product actions-->
                            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                <div class="text-center"><a class="btn btn-outline-dark mt-auto"
                                                            href="<?php echo e(route('product_info', ['product' => $relatedProduct->product_code])); ?>">View
                                        Product</a></div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <?php echo $__env->make('store_locator', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myapp\e-commerce website\resources\views/product_view.blade.php ENDPATH**/ ?>
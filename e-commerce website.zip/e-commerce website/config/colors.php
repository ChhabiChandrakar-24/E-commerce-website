<?php

return [
    'Gold',
    'Rose Gold',
    'Silver',
    'Black',
    'Beige',
    'Blue',
    'Green',
];

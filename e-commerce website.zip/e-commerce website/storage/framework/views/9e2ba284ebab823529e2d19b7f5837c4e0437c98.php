<?php $__env->startSection('content'); ?>
    <main>
        <div class="container-fluid px-4">
            <h1 class="mt-4">Brands</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item"><a href="index.html">Dashboard</a></li>
                <li class="breadcrumb-item active">Brands</li>
            </ol>
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-table me-1"></i>
                    All Brands
                    <a href="<?php echo e(route('brands.create')); ?>" class="btn btn-outline-primary btn-sm float-end"> + Add Brand</a>
                </div>
                <div class="card-body">
                    <?php echo $__env->make('flash_data', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <table id="datatablesSimple">
                        <thead>
                        <tr>
                            <th>Name</th>
                            <th>Image</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tfoot>
                        <tr>
                            <th>Name</th>
                            <th>Image</th>
                            <th>Action</th>
                        </tr>
                        </tfoot>
                        <tbody>
                        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($brand->name); ?></td>
                                <td><img src="<?php echo e(url('brands') . '/' . $brand->image); ?>" alt="<?php echo e($brand->name ?? 'Brand'); ?> Image" width="100"></td>
                                <td style="max-width: 30px">
                                    <a href="<?php echo e(route('brands.edit', ['brand' => $brand->id])); ?>" class="btn btn-sm btn-warning">Edit</a>
                                    <a href="<?php echo e(route('admin_change_brand_status', ['id' => $brand->id, 'status' => $brand->is_active == 1 ? 0 : 1])); ?>" class="btn btn-sm btn-<?php echo e($brand->is_active == 1 ? 'danger' : 'success'); ?>"><?php echo e($brand->is_active == 1 ? 'Deactivate' : 'Activate'); ?></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\learnvern-watch-store\resources\views/admin/brands_list.blade.php ENDPATH**/ ?>
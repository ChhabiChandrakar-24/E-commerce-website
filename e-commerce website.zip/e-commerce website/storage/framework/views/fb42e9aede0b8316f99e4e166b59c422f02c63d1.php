<?php $__env->startSection('content'); ?>
    <div class="container" style="margin-top: 5%;margin-bottom: 5%">
        <!-- Start row -->
        <div class="row">
            <!-- Start col -->
            <div class="col-md-12 col-lg-12 col-xl-12">
                <div class="card m-b-30">
                    <div class="card-header">
                        <h5 class="card-title">Cart</h5>
                    </div>
                    <div class="card-body">
                        <?php echo $__env->make('flash_data', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="row justify-content-center">
                            <div class="col-lg-10 col-xl-8">
                                <div class="cart-container">
                                    <div class="cart-head">
                                        <div class="table-responsive">
                                            <table class="table table-borderless">
                                                <thead>
                                                <tr>
                                                    <th scope="col">#</th>
                                                    <th scope="col">Photo</th>
                                                    <th scope="col">Product</th>
                                                    <th scope="col">Qty</th>
                                                    <th scope="col">Price</th>
                                                    <th scope="col" class="text-right">Total</th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                <form method="post" action="<?php echo e(route('cart.store')); ?>">
                                                    <?php echo csrf_field(); ?>
                                                    <?php $__currentLoopData = $cartData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <th scope="row"><?php echo e($loop->iteration); ?></th>
                                                            <td><img
                                                                    src="<?php echo e($value->getProductData->image); ?>"
                                                                    class="img-fluid" width="35" alt="product"></td>
                                                            <td><?php echo e($value->getProductData->name); ?></td>
                                                            <td>
                                                                <div class="form-group mb-0">
                                                                    <input type="hidden" class="form-control cart-qty"
                                                                           name="cart[]" id="cartQty<?php echo e($loop->iteration); ?>"
                                                                           value="<?php echo e($value->id); ?>">
                                                                    <input type="number" min="0" class="form-control cart-qty"
                                                                           name="cartQty[]" id="cartQty<?php echo e($loop->iteration); ?>"
                                                                           value="<?php echo e($value->quantity); ?>">
                                                                </div>
                                                            </td>
                                                            <td>
                                                                ₹ <?php echo e(!empty($value->getProductData->sale_price) ? $value->getProductData->sale_price : $value->getProductData->price); ?></td>
                                                            <td class="text-right">
                                                                ₹ <?php echo e(!empty($value->getProductData->sale_price) ? ($value->getProductData->sale_price * $value->quantity) : ($value->getProductData->price * $value->quantity)); ?></td>
                                                        </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <div class="cart-body">
                                        <div class="row">
                                            <div class="col-md-12 order-2 order-lg-1 col-lg-5 col-xl-6">
                                                <div class="order-note">
                                                    <!--                                                    <div class="form-group">-->
                                                    <!--                                                        <div class="input-group">-->
                                                    <!--                                                            <input type="search" class="form-control"-->
                                                    <!--                                                                   placeholder="Coupon Code" aria-label="Search"-->
                                                    <!--                                                                   aria-describedby="button-addonTags">-->
                                                    <!--                                                            <div class="input-group-append">-->
                                                    <!--                                                                <button class="input-group-text" type="submit"-->
                                                    <!--                                                                        id="button-addonTags">Apply-->
                                                    <!--                                                                </button>-->
                                                    <!--                                                            </div>-->
                                                    <!--                                                        </div>-->
                                                    <!--                                                    </div>-->
                                                    <div class="form-group">
                                                        <label for="specialNotes">Special Note for this
                                                            order:</label>
                                                        <textarea class="form-control" name="specialNotes"
                                                                  id="specialNotes" rows="3"
                                                                  placeholder="Message here"><?php echo e($user->commentData->comment ?? null); ?></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-12 order-1 order-lg-2 col-lg-7 col-xl-6">
                                                <div class="order-total table-responsive ">
                                                    <table class="table table-borderless text-right">
                                                        <tbody>
                                                        <tr>
                                                            <td>Sub Total :</td>
                                                            <td>₹ <?php echo e($subtotal); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Shipping :</td>
                                                            <td>₹ <?php echo e($shipping); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Tax(<?php echo e($tax); ?>%) :</td>
                                                            <td>₹ <?php echo e($taxAmount); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td class="f-w-7 font-18"><h4>Amount :</h4></td>
                                                            <td class="f-w-7 font-18"><h4>₹ <?php echo e($total); ?></h4></td>
                                                        </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="cart-footer text-right">
                                        <input type="submit" class="btn btn-outline-primary my-1"
                                               value="Update Cart"></input>
                                        </form>
                                        <a href="<?php echo e(route('store_order')); ?>" class="btn btn-outline-success my-1"><i
                                                class="fa fa-credit-card-alt" aria-hidden="true"></i>
                                            &nbsp;Proceed to Checkout</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End col -->
        </div>
        <!-- End row -->
    </div>
    <?php echo $__env->make('store_locator', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myapp\e-commerce website\resources\views/cart.blade.php ENDPATH**/ ?>
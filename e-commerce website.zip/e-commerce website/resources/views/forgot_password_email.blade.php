Hi, we have received your request for password reset.

Please click <a href="{{ env('APP_URL') . 'reset-password/' . $token . '?email=' . urlencode($email) }}"> here </a> to reset your password.

Thanks,
chhabi Web Store Team.

<?php $__env->startSection('content'); ?>
    <main>
        <div class="container-fluid px-4">
            <h1 class="mt-4">Lineitems</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin_home')); ?>">Dashboard</a></li>
                <li class="breadcrumb-item active">Lineitems</li>
            </ol>
            <div class="card mb-4">
                <div class="card-body">
                    <?php echo $__env->make('flash_data', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <table id="datatablesSimple">
                        <thead>
                        <tr>
                            <th>Order id</th>
                            <th>user Name</th>
                            <th>Product Name</th>
                            <th>Quantity</th>
                            <th>Price</th>
                            <th>Total Price</th>
                        </tr>
                        </thead>
                        <tfoot>
                        <tr>
                            <th>Order id</th>
                            <th>user Name</th>
                            <th>Product Name</th>
                            <th>Quantity</th>
                            <th>Price</th>
                            <th>Total Price</th>
                        </tr>
                        </tfoot>
                        <tbody>
                        <?php $__currentLoopData = $orderData->lineitemsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lineitemData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>LV - <?php echo e($lineitemData->order_id); ?></td>
                                <td><?php echo e($lineitemData->customerData->fname); ?></td>
                                <td><?php echo e($lineitemData->productData->name); ?></td>
                                <td><?php echo e($lineitemData->quantity); ?></td>
                                <td><?php echo e($lineitemData->price); ?></td>
                                <td><?php echo e($lineitemData->total_price); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\learnvern-watch-store\resources\views/admin/lineitems_list.blade.php ENDPATH**/ ?>